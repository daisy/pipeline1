This is the target platform for the DAISY Pipeline project.

It includes:

 * Eclipse RCP SDK 3.5.1
   * all features and plugins
   * com.ibm.icu replaced by com.ibm.icu.base (in the plugins and feature.xml)
 * Eclipse Delta Pack 3.5.1
   * all plugins
   * replaced swt.gtk.linux.* with version 3.5.2.M20100113 (to fix bug #287307)
   * org.eclipse.equinox.executable feature
   * org.eclipse.rcp feature
 * Eclipse RCP custom additions
   * exported from the org.eclipse.rcp.additions-feature and org.eclipse.rcp.additions.source-feature Pipeline projects, with the target platform set to Eclipse SDK 3.5.1